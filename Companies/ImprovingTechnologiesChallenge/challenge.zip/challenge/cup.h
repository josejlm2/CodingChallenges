#pragma once
#include "die.h"
class cup
{
public:
	cup(void);
	~cup(void);
	int rollDice(int a);
};


